#pragma once
#include <iostream>
#include <vector>
#include <ctime>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <sstream>


class Juego
{
private:

	sf::RenderWindow* window;
	sf::Event evt;
	sf::VideoMode videoM;

	sf::Vector2i mousePos;
	sf::Vector2f mousePosVista;

	sf::Font fuente;

	sf::Text texto;

	float tempEnems, tempEnemsMax;
	int maxEnems;
	unsigned puntos;

	std::vector<sf::CircleShape> enemigos;
	sf::CircleShape enemigo;

	void iniciarVaria();
	void iniciarVent();
	void iniciarFuente();
	void iniciarTexto();
	void iniciarEnem();

public:
	
	Juego();
	virtual ~Juego();
	
	const bool ejecutando() const;

	void spawnEnemigo();
	
	void actualizarEv();
	void actualizarPosMouse();
	void actualizarTexto();
	void actualizarEnem();
	void actualizar();

	void renderTexto(sf::RenderTarget& target);
	void renderEnem(sf::RenderTarget& target);
	void renderizar();
};

