#include "Juego.h"

int main() {

	std::srand(static_cast<unsigned>(time(NULL)));

	Juego juego;

	sf::Event evento;
	
	while (juego.ejecutando()) {

		juego.actualizar();

		juego.renderizar();
	}

	return 0;
}