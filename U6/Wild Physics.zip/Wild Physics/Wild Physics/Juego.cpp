#include "Juego.h"

void Juego::iniciarVaria()
{
	this->window = nullptr;

	this->puntos = 0;
	this->tempEnemsMax = 20.f;
	this->tempEnems = this->tempEnemsMax;
	this->maxEnems = 20;
}

void Juego::iniciarVent()
{
	this->videoM.width = 800;
	this->videoM.height = 600;
	this->window = new sf::RenderWindow(this->videoM, "Wild Physics");
	this->window->setFramerateLimit(60);
}

Juego::Juego()
{
	this->iniciarVaria();
	this->iniciarVent();
	this->iniciarFuente();
	this->iniciarTexto();
	this->iniciarEnem();
}

Juego::~Juego()
{
	delete this->window;
}

const bool Juego::ejecutando() const
{
	return this->window->isOpen();
}

void Juego::actualizarEv()
{
	while (this->window->pollEvent(this->evt)) {
		switch (this->evt.type) {
		case sf::Event::Closed:
			this->window->close();
			break;

		case sf::Event::KeyPressed:
			if (this->evt.key.code == sf::Keyboard::Escape)
				this->window->close();
			break;
		}
	}
}

void Juego::actualizarPosMouse()
{
	this->mousePos = sf::Mouse::getPosition(*this->window);
	this->mousePosVista = this->window->mapPixelToCoords(this->mousePos);
}

void Juego::iniciarFuente()
{
	if (this->fuente.loadFromFile("Fuente/AnkhSanctuary.ttf")) {
		
	}
}

void Juego::spawnEnemigo()
{
	this->enemigo.setPosition(
		static_cast<float>(rand() % static_cast<int>(this->window->getSize().x - this->enemigo.getRadius())), 
		0.f
	);

	int tipo = rand() % 6;

	switch (tipo) {
	case 0:
		this->enemigo.setRadius(10.0f);
		this->enemigo.setFillColor(sf::Color::Red);
		break;
	case 1:
		this->enemigo.setRadius(20.0f);
		this->enemigo.setFillColor(sf::Color::Black);
		break;
	case 2:
		this->enemigo.setRadius(50.0f);
		this->enemigo.setFillColor(sf::Color::Magenta);
		break;
	case 3:
		this->enemigo.setRadius(28.0f);
		this->enemigo.setFillColor(sf::Color::Green);
		break;
	case 4:
		this->enemigo.setRadius(35.0f);
		this->enemigo.setFillColor(sf::Color::Blue);
		break;
	default:
		this->enemigo.setRadius(65.0f);
		this->enemigo.setFillColor(sf::Color::Yellow);
		break;
	}

	this->enemigos.push_back(this->enemigo);
}

void Juego::iniciarTexto()
{
	this->texto.setFont(this->fuente);
	this->texto.setCharacterSize(20);
	this->texto.setFillColor(sf::Color::Black);
	this->texto.setPosition(0, 0);
	this->texto.setString("NONE");
}

void Juego::actualizarEnem()
{

	if (this->enemigos.size() < this->maxEnems) {
		if (this->tempEnems >= this->tempEnemsMax)
		{
			this->spawnEnemigo();
			this->tempEnems = 0.f;
		}
		else
			this->tempEnems += 1.f;
	}

	for (int i = 0; i < this->enemigos.size(); i++)
	{
		this->enemigos[i].move(0.f, 2.5f);
		
		if (this->enemigos[i].getPosition().y > this->window->getSize().y) { 
			this->enemigos.erase(this->enemigos.begin() + i);
		}

		if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
			if (this->enemigos[i].getGlobalBounds().contains(this->mousePosVista)) {
				
				if (this->enemigos[i].getFillColor() == sf::Color::Blue) {
					this->puntos += 5;
				}

				else if (this->enemigos[i].getFillColor() == sf::Color::Red) {
					this->puntos += 15;
				}

				else if (this->enemigos[i].getFillColor() == sf::Color::Black) {
					this->puntos += 10;
				}

				else if (this->enemigos[i].getFillColor() == sf::Color::Green) {
					this->puntos += 7;
				}
				
				else if (this->enemigos[i].getFillColor() == sf::Color::Magenta) {
					this->puntos += 3;
				}

				else if (this->enemigos[i].getFillColor() == sf::Color::Yellow) {
					this->puntos += 1;
				}

				this->enemigos.erase(this->enemigos.begin() + i);
			}
		}

	}
}

void Juego::renderEnem(sf::RenderTarget& target)
{
	for (auto& e : this->enemigos)
	{
		target.draw(e);
	}
}

void Juego::actualizarTexto()
{
	std::stringstream pts;

	pts << "Puntos: " << this->puntos;

	this->texto.setString(pts.str());
}

void Juego::renderTexto(sf::RenderTarget& target)
{
	target.draw(this->texto);
}

void Juego::actualizar()
{
	this->actualizarEv();

	this->actualizarPosMouse();

	this->actualizarTexto();

	this->actualizarEnem();
}

void Juego::iniciarEnem()
{
	this->enemigo.setPosition(0, 0);
}

void Juego::renderizar()
{
	this->window->clear(sf::Color::White);

	this->renderEnem(*this->window);

	this->renderTexto(*this->window);

	this->window->display();
}