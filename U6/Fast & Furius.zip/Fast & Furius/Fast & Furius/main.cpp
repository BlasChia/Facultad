#include <iostream>
#include <SFML/Graphics.hpp>

const float V0 = 25.0f, VFinal = 200.0f;

int main() {

	sf::RenderWindow window(sf::VideoMode(800, 600), "Fast & Furious");
	window.setFramerateLimit(60);

	sf::CircleShape circulo(50);
	circulo.setOrigin(circulo.getRadius(), circulo.getRadius());
	circulo.setFillColor(sf::Color::White);

	float velocidad = V0;
	float pos = circulo.getRadius();

	while (window.isOpen()) {

		sf::Event evento;

		while (window.pollEvent(evento)) {
			if (evento.type == sf::Event::Closed)
				window.close();
		}

		pos += velocidad;
		if (pos + circulo.getRadius() > 800) {
			pos = -circulo.getRadius();
			velocidad *= 1.2f;
		}

		circulo.setPosition(pos, 600 / 2.0f);

		window.clear();
		window.draw(circulo);
		window.display();

		if (velocidad >= VFinal) {
			break;
		}
	}
}