#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

int main(){

    sf::Texture textura;
    textura.loadFromFile("crosshair.png");
    
    sf::Sprite crosshair(textura);
    
    sf::Vector2u size = crosshair.getTexture()->getSize();
    crosshair.setOrigin(sf::Vector2f(size.x / 2.f, size.y / 2.f));

    sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Crosshair");

    sf::Vector2u tamVent = App.getSize();
    sf::Vector2f centVent(tamVent.x / 2.f, tamVent.y / 2.f);
    crosshair.setPosition(centVent);

    while (App.isOpen()) {

        sf::Event event;
        while (App.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                App.close();
        }

        App.clear();

        App.draw(crosshair);

        App.display();
    }

    return 0;
}
