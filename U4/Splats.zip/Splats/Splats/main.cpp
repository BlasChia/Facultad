#include <SFML/Graphics.hpp>

int main() {

	sf::RenderWindow window(sf::VideoMode(800, 600), "Circulos");

	sf::Texture textCR;
	if (!textCR.loadFromFile("rcircle.png")) {
		return -1;
	}

	sf::Texture textCA;
	if (!textCA.loadFromFile("rcircleb.png")) {
		return -1;
	}

	std::vector<sf::Sprite> circulos;

	while (window.isOpen()) {
		sf::Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed) {
				window.close();
			}

			if (event.type == sf::Event::MouseButtonPressed) {
				sf::Sprite nuevoCirc;
				if (event.mouseButton.button == sf::Mouse::Left) {
					nuevoCirc.setTexture(textCR);
				}
				else if (event.mouseButton.button == sf::Mouse::Right) {
					nuevoCirc.setTexture(textCA);
				}

				nuevoCirc.setPosition(static_cast<float>(event.mouseButton.x), static_cast<float>(event.mouseButton.y));
				circulos.push_back(nuevoCirc);
			}
		}

		window.clear();

		for (const auto& circulo : circulos) {
			window.draw(circulo);
		}

		window.display();
	}

	return 0;
}