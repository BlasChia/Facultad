#include <iostream>
#include <SFML/Graphics.hpp>

sf::RenderWindow window;

void checkTam() {

	sf::Vector2u tama�o = window.getSize();
	if (tama�o.x < 100 || tama�o.y < 100)
		window.setSize(sf::Vector2u(std::max(tama�o.x, 100u), std::max(tama�o.y, 100u)));
	else if (tama�o.x > 1000 || tama�o.y > 1000)
		window.setSize(sf::Vector2u(std::min(tama�o.x, 1000u), std::min(tama�o.y, 1000u)));
}

void handleEvent(sf::Event& event) {

	if (event.type == sf::Event::Resized)
		checkTam();
}

int main() {

	window.create(sf::VideoMode(500, 500), "Adaptaci�n");

	while (window.isOpen()) {

		sf::Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed)
				window.close();
			handleEvent(event);
		}

		window.clear();

		window.display();
	}

	return 0;
}