#include <SFML/Graphics.hpp>
#include <ctime>
#include <cstdlib>

class Enemigo : public sf::Sprite {
public:
	Enemigo(const sf::Texture& texture) : sf::Sprite(texture) {}
};

class Mira : public sf::Sprite {
public:
	Mira(const sf::Texture& texture) : sf::Sprite(texture) {}
};

int main() {
	srand(time(NULL));

	sf::RenderWindow window(sf::VideoMode(800, 600), "Clickale");
	window.setFramerateLimit(60);
	window.setMouseCursorVisible(false);

	sf::Texture texturaEnem;
	if (!texturaEnem.loadFromFile("et.png")) {
		return 1;
	}
	sf::Texture texturaMira;
	if (!texturaMira.loadFromFile("crosshair.png")) {
		return 1;
	}

	Enemigo enemigo(texturaEnem);
	enemigo.setScale(0.1, 0.1);
	enemigo.setPosition(rand() % window.getSize().x, rand() % window.getSize().y);

	if (enemigo.getPosition().x < 0) {
		enemigo.setPosition(0, enemigo.getPosition().y);
	}
	else if (enemigo.getPosition().x + enemigo.getGlobalBounds().width > window.getSize().x) {
		enemigo.setPosition(window.getSize().x - enemigo.getGlobalBounds().width, enemigo.getPosition().y);
	}

	if (enemigo.getPosition().y < 0) {
		enemigo.setPosition(enemigo.getPosition().x, 0);
	}
	else if (enemigo.getPosition().y + enemigo.getGlobalBounds().height > window.getSize().y) {
		enemigo.setPosition(enemigo.getPosition().x, window.getSize().y - enemigo.getGlobalBounds().height);
	}

	Mira mira(texturaMira);
	mira.setScale(0.5, 0.5);
	sf::Vector2i posMira = sf::Mouse::getPosition(window);
	mira.setPosition(posMira.x, posMira.y);
	mira.setOrigin(mira.getLocalBounds().width / 2, mira.getLocalBounds().height / 2);

	int ContEnemigos = 0;

	while (window.isOpen()) {
		
		sf::Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed) {
				window.close();
			}

			if (event.type == sf::Event::MouseButtonPressed) {
				if (event.mouseButton.button == sf::Mouse::Left) {
					sf::Vector2i posMouse = sf::Mouse::getPosition(window);
					sf::FloatRect bordes = enemigo.getGlobalBounds();

					if (bordes.contains(posMouse.x, posMouse.y)) {
						ContEnemigos++;
						enemigo.setPosition(rand() % window.getSize().x, rand() % window.getSize().y);
					}
				}
			}

			sf::Vector2i posMira = sf::Mouse::getPosition(window);
			mira.setPosition(posMira.x, posMira.y);
		}

		if (ContEnemigos >= 5) {
			break;
		}

		window.clear();
		window.draw(enemigo);
		window.draw(mira);
		window.display();
	}

	return 0;
}