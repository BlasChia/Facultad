#include <SFML/Graphics.hpp>
#include <ctime>
#include <cstdlib>

class Crosshair : public sf::Sprite {
public:
    Crosshair(const sf::Texture& texture) : sf::Sprite(texture) {}
};

int main() {
    srand(time(NULL));

    sf::RenderWindow window(sf::VideoMode(800, 600), "Click The Enemy!");
    window.setFramerateLimit(60);

    sf::Texture textureCrosshair;
    if (!textureCrosshair.loadFromFile("crosshair.png")) {
        return EXIT_FAILURE;
    }

    Crosshair crosshair(textureCrosshair);
    crosshair.setScale(0.5, 0.5);

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
        }

        sf::Vector2i crosshairPos = sf::Mouse::getPosition(window);
        crosshair.setPosition(crosshairPos.x, crosshairPos.y);

        window.clear();
        window.draw(crosshair);
        window.display();
    }