#include <SFML/Graphics.hpp>

int main() {

	sf::RenderWindow window(sf::VideoMode(800, 600), "Drag");

	sf::Texture textura;
	if (!textura.loadFromFile("rcircle.png")) {
		return -1;
	}

	sf::Sprite circulos[4];
	for (int i = 0; i < 4; i++) {
		circulos[i].setTexture(textura);
		circulos[i].setScale(0.5f, 0.5f);
	}

	circulos[0].setPosition(0, 0);
	circulos[1].setPosition(window.getSize().x - circulos[1].getGlobalBounds().width, 0);
	circulos[2].setPosition(0, window.getSize().y - circulos[2].getGlobalBounds().height);
	circulos[3].setPosition(window.getSize().x - circulos[3].getGlobalBounds().width, window.getSize().y - circulos[3].getGlobalBounds().height);

	sf::Vector2i posMouse;

	int arrastCirc = -1;

	while (window.isOpen()) {

		sf::Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed) {
				window.close();
			}
			else if (event.type == sf::Event::MouseButtonPressed) {
				for (int i = 0; i < 4; i++) {
					if (circulos[i].getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) {
						arrastCirc = i;
						posMouse = sf::Mouse::getPosition(window);
						break;
					}
				}
			}
			else if (event.type == sf::Event::MouseButtonReleased) {

				arrastCirc = -1;
			}
			else if (event.type == sf::Event::MouseMoved && arrastCirc != -1) {

				sf::Vector2i nuevaPosMouse = sf::Mouse::getPosition(window);
				sf::Vector2f delta = sf::Vector2f(nuevaPosMouse) - sf::Vector2f(posMouse);
				circulos[arrastCirc].move(delta);
				posMouse = nuevaPosMouse;
			}
		}

		window.clear();

		for (int i = 0; i < 4; i++) {
			window.draw(circulos[i]);
		}

		window.display();
	}

	return 0;
}