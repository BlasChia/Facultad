#include <SFML/Graphics.hpp>
#include <cmath>

int main() {

	sf::RenderWindow window(sf::VideoMode(800, 600), "Atrapado");

	sf::Texture cuadAmar;
	if (!cuadAmar.loadFromFile("cuad_yellow.png")) {
		return 1;
	}
	sf::Sprite spCuadAmar(cuadAmar);

	sf::Texture circVerde;
	if (!circVerde.loadFromFile("rcircleg.png")) {
		return 1;
	}
	sf::Sprite spCircVerde(circVerde);

	spCuadAmar.setScale(128.f / 512.f, 128.f / 512.f);

	sf::Vector2f posCuad(100, 100);
	bool esCirc = false;

	while (window.isOpen()) {

		sf::Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed) {
				window.close();
			}

			if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape) {
				window.close();
			}

			if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Space) {
				esCirc = !esCirc;
			}
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
			posCuad.y -= 1;
		}
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
			posCuad.y += 1;
		}
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
			posCuad.x -= 1;
		}
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
			posCuad.x += 1;
		}

		if (posCuad.x < 0) {
			posCuad.x = 0;
		}
		if (posCuad.x > 800 - spCuadAmar.getGlobalBounds().width) {
			posCuad.x = 800 - spCuadAmar.getGlobalBounds().width;
		}
		if (posCuad.y < 0) {
			posCuad.y = 0;
		}
		if (posCuad.y > 600 - spCuadAmar.getGlobalBounds().height) {
			posCuad.y = 600 - spCuadAmar.getGlobalBounds().height;
		}

		if (esCirc) {
			spCircVerde.setPosition(posCuad);
		}
		else {
			spCuadAmar.setPosition(posCuad);
		}

		window.clear();

		if (esCirc) {
			window.draw(spCircVerde);
		}
		else {
			window.draw(spCuadAmar);
		}

		window.display();
	}

	return 0;
}